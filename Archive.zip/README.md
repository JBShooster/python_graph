#Write-Up

 - To run the program, access the directory in your terminal and enter "python app.py"
 - The runtime is constant across the board. The only exception is for the "is_linked" function where the new path is created.
 - I felt that creating an object with easy-to-understand functions was the best way to go. I also give the user the ability to determine if the Graph is directed or undirected. For the sake of this exercise we treat the graph as undirected.
